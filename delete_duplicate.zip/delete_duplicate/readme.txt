=============================
-
Delete duplicates script
-
=============================

What the code does?

This code is done to delete duplicate lines of text in trained labels. If you accidentaly clicked more than once on "Export Labels", with this script you can solve that issue.

Scripted by: Lyron and Ezequiel

