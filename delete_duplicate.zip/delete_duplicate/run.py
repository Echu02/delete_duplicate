from pathlib import Path
import hashlib
import os

source_dir = Path(r'E:\Scripts\delete_duplicate\labels')
files = list(x for x in source_dir.iterdir() if x.is_file())

completed_lines_hash = set()

for i in range(len(files)):
    file = Path(files[i])
    outfile = str(i) + file.suffix
    with open(file) as fReader, open(outfile, "w") as fOut:
        for line in fReader:
            hashValue = hashlib.md5(line.rstrip().encode('utf-8')).hexdigest()
            if hashValue not in completed_lines_hash:
                fOut.write(line)
                completed_lines_hash.add(hashValue)
